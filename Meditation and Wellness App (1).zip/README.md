
  # Meditation and Wellness App

  This is a code bundle for Meditation and Wellness App. The original project is available at https://www.figma.com/design/OH6IEFb1elB6pwPqKl7Qty/Meditation-and-Wellness-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  